import sys, urllib.request, urllib.parse, json, re, time, http.cookiejar, random, gzip, base64, ssl
import xbmc, xbmcgui, xbmcplugin
HANDLE = int(sys.argv[1])
def random_ua():
    br_vers = {
        'Firefox': ['%s.0' % i for i in range(120, 147)],
        'Chrome': ['%s.0.0.0' % i for i in range(120, 144)],
        'Edg': ['%s.0.0.0' % i for i in range(120, 144)],
    }
    templates = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{v}) Gecko/20100101 Firefox/{v}',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v} Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v} Safari/537.36 Edg/{v}',
    ]
    b = random.choice(list(br_vers.keys()))
    v = random.choice(br_vers[b])
    t = next((x for x in templates if b.lower() in x.lower()), templates[0])
    return t.format(v=v)


def _browser_headers(referer=None):
    h = {
        'User-Agent': random_ua(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.8',
        'Connection': 'keep-alive',
    }
    if referer:
        h['Referer'] = referer
    return h

# --- cookie session + login support (credentials embedded by user decision, private use) ---
_jar = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_jar))
_logged_in = set()


def xh_initials(html):
    m = re.search(r'>window\.initials=(.*?);\s*</script>', html or '', re.S)
    if not m:
        return {}
    try:
        return json.loads(m.group(1))
    except Exception:
        return {}


def xh_videos(html):
    items = []
    j = xh_initials(html)
    try:
        vids = j.get('layoutPage', {}).get('videoListProps', {}).get('videoThumbProps', [])
    except Exception:
        vids = []
    for v in vids:
        try:
            title = v.get('title', '')
            url = v.get('pageURL', '')
            thumb = v.get('thumbURL', '')
            dur = v.get('duration', 0)
            if not url or not title:
                continue
            items.append((title, url, thumb, dur))
        except Exception:
            continue
    return items


_SESSION_UA = random_ua()

def fetch_tls(url, tls_ver):
    jar = http.cookiejar.CookieJar()
    if tls_ver == '1.3':
        ctx = ssl.create_default_context()
    elif tls_ver == '1.2':
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
    else:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS)
        ctx.options |= ssl.OP_NO_TLSv1_3 | ssl.OP_NO_TLSv1_2
    opener = urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(jar),
        urllib.request.HTTPSHandler(context=ctx))
    req = urllib.request.Request(url, headers=_browser_headers())
    with opener.open(req, timeout=25) as r:
        raw = r.read()
    if raw[:2] == b'\x1f\x8b':
        raw = gzip.decompress(raw)
    return raw.decode('utf-8', 'ignore')

def main():
    rep = []
    for ver in ['1.3', '1.2', '1.1']:
        try:
            html = fetch_tls('https://xhamster.com/newest', ver)
            n = len(xh_videos(html))
            rep.append("TLS %s: len=%d videos=%d" % (ver, len(html), n))
            if n: break
        except Exception as e:
            rep.append("TLS %s: ERROR %s %s" % (ver, type(e).__name__, str(e)[:50]))
    xbmcgui.Dialog().textviewer('XH Diag v4', "\n".join(rep))
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    main()
