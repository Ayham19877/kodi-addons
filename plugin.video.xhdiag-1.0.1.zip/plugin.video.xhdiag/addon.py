import sys, urllib.request, urllib.parse, json, re, time, http.cookiejar, random, gzip, base64
import xbmc, xbmcgui, xbmcplugin
HANDLE = int(sys.argv[1])
_jar = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_jar))
def random_ua():
    br_vers = {
        'Firefox': ['%s.0' % i for i in range(120, 147)],
        'Chrome': ['%s.0.0.0' % i for i in range(120, 144)],
        'Edg': ['%s.0.0.0' % i for i in range(120, 144)],
    }
    templates = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{v}) Gecko/20100101 Firefox/{v}',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v} Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v} Safari/537.36 Edg/{v}',
    ]
    b = random.choice(list(br_vers.keys()))
    v = random.choice(br_vers[b])
    t = next((x for x in templates if b.lower() in x.lower()), templates[0])
    return t.format(v=v)


def _browser_headers(referer=None):
    h = {
        'User-Agent': random_ua(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.8',
        'Connection': 'keep-alive',
    }
    if referer:
        h['Referer'] = referer
    return h

# --- cookie session + login support (credentials embedded by user decision, private use) ---
_jar = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_jar))
_logged_in = set()


def _raw(url, data=None, referer=None):
    req = urllib.request.Request(url, data=data, headers=_browser_headers(referer))
    with _opener.open(req, timeout=25) as r:
        raw = r.read()
    if raw[:2] == b'\x1f\x8b':
        try:
            import gzip
            raw = gzip.decompress(raw)
        except Exception:
            pass
    return raw.decode('utf-8', 'ignore')



def http_get(url):
    pass  # diag: no login
    return _raw(url)


def xh_initials(html):
    m = re.search(r'>window\.initials=(.*?);\s*</script>', html or '', re.S)
    if not m:
        return {}
    try:
        return json.loads(m.group(1))
    except Exception:
        return {}


def xh_videos(html):
    items = []
    j = xh_initials(html)
    try:
        vids = j.get('layoutPage', {}).get('videoListProps', {}).get('videoThumbProps', [])
    except Exception:
        vids = []
    for v in vids:
        try:
            title = v.get('title', '')
            url = v.get('pageURL', '')
            thumb = v.get('thumbURL', '')
            dur = v.get('duration', 0)
            if not url or not title:
                continue
            items.append((title, url, thumb, dur))
        except Exception:
            continue
    return items



def main():
    rep = []
    try:
        html = http_get('https://xhamster.com/newest')
    except Exception as e:
        xbmcgui.Dialog().textviewer('XH Diag', "FETCH ERROR: %s %s" % (type(e).__name__, str(e)[:80]))
        xbmcplugin.endOfDirectory(HANDLE)
        return
    t = re.search(r'<title>([^<]*)</title>', html)
    rep.append("title: " + (t.group(1).strip()[:70] if t else "none"))
    rep.append("len: %d" % len(html))
    txt = re.sub(r'<script.*?</script>', ' ', html, flags=re.S)
    txt = re.sub(r'<style.*?</style>', ' ', txt, flags=re.S)
    txt = re.sub(r'<[^>]+>', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    rep.append("text: " + txt[:300])
    forms = re.findall(r'<form[^>]*action="([^"]*)"', html)[:3]
    rep.append("forms: " + str(forms))
    rep.append("has 'age': " + str('age' in html.lower()[:5000]))
    rep.append("has 'captcha': " + str('captcha' in html.lower()[:5000]))
    rep.append("has 'consent': " + str('consent' in html.lower()[:5000]))
    ck = [(c.name, c.value[:20]) for c in _jar]
    rep.append("cookies: " + str(ck)[:200])
    xbmcgui.Dialog().textviewer('XH Diag v2', "\n".join(rep))
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    main()
