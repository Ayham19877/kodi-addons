import sys, urllib.request, urllib.parse, json, re, time, http.cookiejar, random, gzip, base64, ssl
import xbmc, xbmcgui, xbmcplugin
HANDLE = int(sys.argv[1])
_jar = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_jar))
def random_ua():
    br_vers = {
        'Firefox': ['%s.0' % i for i in range(120, 147)],
        'Chrome': ['%s.0.0.0' % i for i in range(120, 144)],
        'Edg': ['%s.0.0.0' % i for i in range(120, 144)],
    }
    templates = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{v}) Gecko/20100101 Firefox/{v}',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v} Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v} Safari/537.36 Edg/{v}',
    ]
    b = random.choice(list(br_vers.keys()))
    v = random.choice(br_vers[b])
    t = next((x for x in templates if b.lower() in x.lower()), templates[0])
    return t.format(v=v)


def _browser_headers(referer=None):
    h = {
        'User-Agent': random_ua(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.8',
        'Connection': 'keep-alive',
    }
    if referer:
        h['Referer'] = referer
    return h

# --- cookie session + login support (credentials embedded by user decision, private use) ---
_jar = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_jar))
_logged_in = set()


def _raw(url, data=None, referer=None):
    req = urllib.request.Request(url, data=data, headers=_browser_headers(referer))
    with _opener.open(req, timeout=25) as r:
        raw = r.read()
    if raw[:2] == b'\x1f\x8b':
        try:
            import gzip
            raw = gzip.decompress(raw)
        except Exception:
            pass
    return raw.decode('utf-8', 'ignore')



def xh_initials(html):
    m = re.search(r'>window\.initials=(.*?);\s*</script>', html or '', re.S)
    if not m:
        return {}
    try:
        return json.loads(m.group(1))
    except Exception:
        return {}


def xh_videos(html):
    items = []
    j = xh_initials(html)
    try:
        vids = j.get('layoutPage', {}).get('videoListProps', {}).get('videoThumbProps', [])
    except Exception:
        vids = []
    for v in vids:
        try:
            title = v.get('title', '')
            url = v.get('pageURL', '')
            thumb = v.get('thumbURL', '')
            dur = v.get('duration', 0)
            if not url or not title:
                continue
            items.append((title, url, thumb, dur))
        except Exception:
            continue
    return items


_SESSION_UA = random_ua()
def _login_xhamster(base, user, pwd):
    try:
        before = set(c.name for c in _jar)
        data = urllib.parse.urlencode({'username': user, 'password': pwd, 'remember': 'on'}).encode()
        html = _raw(base + '/login', data=data, referer=base + '/login')
        after = set(c.name for c in _jar)
        if after - before:
            return True
        if 'loginForm' not in html and 'name="password"' not in html:
            return True
        return False
    except Exception:
        return False



def main():
    rep = []
    kb1 = xbmc.Keyboard('', 'xhamster username')
    kb1.doModal()
    if not (kb1.isConfirmed() and kb1.getText()):
        xbmcplugin.endOfDirectory(HANDLE); return
    kb2 = xbmc.Keyboard('', 'xhamster password')
    kb2.doModal()
    if not (kb2.isConfirmed() and kb2.getText()):
        xbmcplugin.endOfDirectory(HANDLE); return
    user, pwd = kb1.getText(), kb2.getText()
    ok = _login_xhamster('https://xhamster.com', user, pwd)
    rep.append("login func: " + str(ok))
    # check REAL auth state: fetch homepage, look for username/logout
    try:
        home = _raw('https://xhamster.com/')
    except Exception as e:
        home = ''
    rep.append("home len=%d" % len(home))
    rep.append("has username in page: " + str(user.lower() in home.lower()))
    rep.append("has 'logout': " + str('logout' in home.lower()))
    rep.append("has 'login' link still: " + str('>log in<' in home.lower() or '/login' in home[:3000].lower()))
    xbmcgui.Dialog().textviewer('XH Auth Check', "\n".join(rep))
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    main()
